export class Books {
    bookId: number;
    bookName: string;
    bookAuthor: string;
    bookGenre: string;
    noOfCopies: number;
}
