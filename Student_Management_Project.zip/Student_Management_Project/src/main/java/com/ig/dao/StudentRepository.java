package com.ig.dao;

import org.springframework.data.repository.CrudRepository;

import com.ig.dto.Student;

public interface StudentRepository  extends CrudRepository<Student, Integer>{

}


// class StudentRepository$$y93u434 implements StudentRepository{








//}